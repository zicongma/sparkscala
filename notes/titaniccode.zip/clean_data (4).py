import matplotlib.pyplot as plt
import pandas as pd    #Dataframe library to manipulate data
import numpy as np      
import re  #We'll be using regular expressions to extract the titles from people's names. Like Mr, Mrs, Count etc
from sklearn.model_selection import KFold   #for k-fold cross-validation
from sklearn import model_selection as cv      #cross-validation
from sklearn.linear_model import LogisticRegression  
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn.ensemble import GradientBoostingClassifier
import xgboost 
from sklearn.model_selection import GridSearchCV   #Support for Hyper-parameter Tuning
from cloudpickle import dumps, dump, load
from typing import List
import os
import requests
import json
from datetime import datetime

train = pd.read_csv('/data/titanic/train.csv')
test = pd.read_csv('/data/titanic/test.csv')

#Make a copy of test for later use. 
test_orig = test[:]

#In order to avoid duplication of code owing to applying same operations to both dataframes
#we combine the test and train dataframes into one. We'll split them later at time of training.
seperator = train.shape[0] #get the length of training data to slie the combined data frame later
frames = [train, test]
titanic = pd.concat(frames)

#Cabin has too many missing values. Isn't very important to survial, so we drop it.
titanic.drop(["Cabin"], axis = 1, inplace = True)

#Senisble imputation of missing Fare values
median_fare = titanic.loc[(titanic["Pclass"] == 3) & (titanic["Embarked"] == "S") & (titanic["Age"] >= 55)].dropna()["Fare"].median()
titanic["Fare"] = titanic["Fare"].fillna(median_fare)

def get_title(name):
    """
    Use a regular expression to search for a title.  Titles always consist of
    capital and lowercase letters, and end with a period.

    Takes a name as input and returns the title string as output
    """

    title_search = re.search(' ([A-Za-z]+)\.', name)
    # If the title exists, extract and return it.
    if title_search:
        return title_search.group(1)
    return ""


titanic["Title"] = titanic["Name"].apply(get_title)  #We dropped "Name" earlier. So, we use original data.

#Condense the title into smaller, and more meaningful categories.
Title_Dictionary = {
                        "Capt":       "Officer",
                        "Col":        "Officer",
                        "Major":      "Officer",
                        "Jonkheer":   "Royal",
                        "Don":        "Royal",
                        "Sir" :       "Royal",
                        "Dr":         "Officer",
                        "Rev":        "Officer",
                        "Countess":   "Royal",
                        "Dona":       "Royal",
                        "Mme":        "Mrs",
                        "Mlle":       "Miss",
                        "Ms":         "Mrs",
                        "Mr" :        "Mr",
                        "Mrs" :       "Mrs",
                        "Miss" :      "Miss",
                        "Master" :    "Master",
                        "Lady" :      "Royal"

                        }

def titlemap(x):
    return Title_Dictionary[x]


titanic["Title"] = titanic["Title"].apply(titlemap)

#Fill in the missing age values by categorising the data and imputing the missing Age values 
#in a particular category by the median Age of that category.
#We could replace the age by the median but that would rob our dataset of precious variance 
#which is important in training our classifier to perform better.

def fillAges(row):
    if not(np.isnan(row['Age'])):
        return row['Age']

    if row['Sex']=='female' and row['Pclass'] == 1:
        if row['Title'] == 'Miss':
            return 30
        elif row['Title'] == 'Mrs':
            return 45
        elif row['Title'] == 'Officer':
            return 49
        elif row['Title'] == 'Royalty':
            return 39

    elif row['Sex']=='female' and row['Pclass'] == 2:
        if row['Title'] == 'Miss':
            return 20
        elif row['Title'] == 'Mrs':
            return 30

    elif row['Sex']=='female' and row['Pclass'] == 3:
        if row['Title'] == 'Miss':
            return 18
        elif row['Title'] == 'Mrs':                
            return 31

    elif row['Sex']=='male' and row['Pclass'] == 1:
        if row['Title'] == 'Master':
            return 6
        elif row['Title'] == 'Mr':
            return 41.5
        elif row['Title'] == 'Officer':
            return 52
        elif row['Title'] == 'Royalty':
            return 40

    elif row['Sex']=='male' and row['Pclass'] == 2:
        if row['Title'] == 'Master':
            return 2
        elif row['Title'] == 'Mr':
            return 30
        elif row['Title'] == 'Officer':
                return 41.5

    elif row['Sex']=='male' and row['Pclass'] == 3:
        if row['Title'] == 'Master':
            return 6
        elif row['Title'] == 'Mr':
            return 26

titanic["Age"] = titanic.apply(fillAges, axis = 1)

#a Rare title indicates towards a higher chances of survival and hence, more chnaces or survival
#We denote Rare titles by 1 and The common ones by 0
def isRare(title):
    if title == "Mr" or title == "Mrs" or title == "Master" or title == "Miss":
        return 0
    return 1

titanic["Title"] = titanic["Title"].apply(isRare)

#Combing Siblings, Spouses, Parents or children onboard to a single Family variable
titanic["Family"] = titanic["Parch"] + titanic["SibSp"]

#Being a child improves your chances of survival. 
titanic["Child"] = 0
titanic.loc[titanic["Age"] <= 18, "Child"] = 1


#Sex is non-numeric data which can't be handled by our classifier. 
titanic.loc[titanic["Sex"] == "male", "Sex"] = 0    #set male to 0 and female to 1
titanic.loc[titanic["Sex"] == "female", "Sex"] =1

titanic["Sex"] = titanic["Sex"].astype(int)


#Embarked is non-numeric data. Therefore we are going to build a couple of categorical variables to
#represent embarked
titanic["Q"] = 0
titanic.loc[titanic["Embarked"] == "Q", "Q"] = 1

titanic["S"] = 0
titanic.loc[titanic["Embarked"] == "S", "S"] = 1

#predictors = ["Age", "Q", "S", "Fare", "Pclass", "Sex", "Family", "Title", "Child"] #0.7655

#The predictors that we are going to use
predictors = ["Q", "S", "Fare", "Pclass", "Sex", "Family", "Title", "Child"]

#Break the combined data set into test and train data
target = titanic["Survived"].iloc[:seperator].to_frame()
#print(target.shape())
train = titanic[predictors][:seperator]
test = titanic[predictors][seperator:]

train_orig= titanic[["Q", "S", "Fare", "Pclass", "Sex", "Family", "Title", "Child"]+["Survived"]][:seperator]

train.to_csv('train_clean.csv', index=False)
test.to_csv('test_clean.csv', index=False)
target.to_csv('target.csv', index=False)
test_orig.to_csv('test_orig.csv', index=False)

train_orig.to_csv('train_orig.csv', index=False)

# context.logger.info('TITANIC COLS '+ str(titanic.columns)+' '+str(titanic.shape)) 

# context.logger.info('TITANIC train_orig COLS '+ str(train_orig.columns)+' '+str(train_orig.shape))
# context.log_dataset('train_orig', df=train_orig, format=format, index=False)

# context.logger.info('TRAIN COLS '+ str(train.columns)+' '+str(train.shape)) 
# context.logger.info('TEST COLS '+ str(test.columns)+' '+str(test.shape))
# context.logger.info('TARGET COLS '+ str(target.columns)+' '+str(target.shape))

# context.logger.info('saving train dataframe to {}'.format(context.artifact_path))
# context.log_dataset('train', df=train, format=format, index=False)
# context.logger.info('saving test dataframe to {}'.format(context.artifact_path))
# context.log_dataset('test_clean', df=test, format=format, index=False)
# context.logger.info('saving target dataframe to {}'.format(context.artifact_path))
# context.log_dataset('target', df=target, format=format, index=False)