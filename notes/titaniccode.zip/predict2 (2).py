from cnvrg import Endpoint
from cloudpickle import dumps, dump, load
import numpy as np

#perform the prediction
e = Endpoint()
xgb = load(open('/cnvrg/xgbmodel.pkl', 'rb'))
svmc = load(open('/cnvrg/svmcmodel.pkl', 'rb'))

# load an image and predict the class
def predict(data):
    test = np.asarray(data)
    print(test)
    e.log_metric("test", test)
    xgb_preds = xgb.predict_proba(test).transpose()[1]
    svmc_preds = svmc.predict_proba(test).transpose()[1]

    #Assign different weightages to the classifiers
    ensemble_preds = xgb_preds*0.75 + svmc_preds*0.25

    for x in range(len(ensemble_preds)):
        if ensemble_preds[x] >= 0.5:
            ensemble_preds[x] = 1
        else:
            ensemble_preds[x] = 0

    xgb_results  = xgb_preds
    svmc_results  = svmc_preds
    ensemble_results  = ensemble_preds
    e.log_metric("xgb", xgb_results)
    e.log_metric("svmc", svmc_results)
    e.log_metric("ensemble", ensemble_results)
    return str(ensemble_results) 