import matplotlib.pyplot as plt
import pandas as pd    #Dataframe library to manipulate data
import numpy as np      
import re  #We'll be using regular expressions to extract the titles from people's names. Like Mr, Mrs, Count etc
from sklearn.model_selection import KFold   #for k-fold cross-validation
from sklearn import model_selection as cv      #cross-validation
from sklearn.linear_model import LogisticRegression  
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn.ensemble import GradientBoostingClassifier
import xgboost 
from sklearn.model_selection import GridSearchCV   #Support for Hyper-parameter Tuning
from cloudpickle import dumps, dump, load
from typing import List
import os
import requests
import json
from datetime import datetime

test = pd.read_csv('/input/clean_data/test_clean.csv')
test_orig = pd.read_csv('/input/clean_data/test_orig.csv')

#xgb_model_file, xgb_model_obj, _ = mlrun.artifacts.get_model(xgb)
xgb = load(open('/input/train/xgbmodel.pkl', 'rb'))

   
#svmc_model_file, svmc_model_obj, _ = mlrun.artifacts.get_model(svmc)
svmc = load(open('/input/train/svmcmodel.pkl', 'rb'))

xgb_preds = xgb.predict_proba(test).transpose()[1]
svmc_preds = svmc.predict_proba(test).transpose()[1]

#Assign different weightages to the classifiers
ensemble_preds = xgb_preds*0.75 + svmc_preds*0.25

for x in range(len(ensemble_preds)):
    if ensemble_preds[x] >= 0.5:
        ensemble_preds[x] = 1
    else:
        ensemble_preds[x] = 0

results  = ensemble_preds.astype(int)

#Generate the final submission file.
submission = pd.DataFrame({"PassengerId": test_orig["PassengerId"], "Survived": results})

submission.to_csv('submission.csv', index=False)
#context.log_dataset('submission', df=submission, format=format, index=False)
#submission.to_csv("kaggle1.csv", index=False)