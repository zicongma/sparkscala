import matplotlib.pyplot as plt
import pandas as pd    #Dataframe library to manipulate data
import numpy as np      
import re  #We'll be using regular expressions to extract the titles from people's names. Like Mr, Mrs, Count etc
from sklearn.model_selection import KFold   #for k-fold cross-validation
from sklearn import model_selection as cv      #cross-validation
from sklearn.linear_model import LogisticRegression  
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn.ensemble import GradientBoostingClassifier
import xgboost 
from sklearn.model_selection import GridSearchCV   #Support for Hyper-parameter Tuning
from cloudpickle import dumps, dump, load
from typing import List
import os
import requests
import json
from datetime import datetime

train = pd.read_csv('/input/clean_data/train_clean.csv')
target = pd.read_csv('/input/clean_data/target.csv')
train_orig = pd.read_csv('/input/clean_data/train_orig.csv')

# context.logger.info('TRAIN() TRAIN COLS '+ str(train_orig.columns)+' '+str(train_orig.shape)) 
# context.logger.info('TRAIN() TRAIN COLS '+ str(train.columns)+' '+str(train.shape)) 
# context.logger.info('TRAIN() TARGET COLS '+ str(target.columns)+' '+str(target.shape))


#Build an ensemble of classifiers. Hyper-parameters chosen through cross validation
xgb = xgboost.XGBClassifier(learning_rate = 0.05, n_estimators=500);
svmc = svm.SVC(C = 5, probability = True)

#fit the data
xgb.fit(train, target)
svmc.fit(train, target)

with open('xgbmodel.pkl', 'wb') as f:
    dump(xgb, f)

# dumps(xgb, open("xgbmodel.pkl", "wb"))
# context.log_model("xgbmodel", 
#                   body=model_bin_xgb,
#                   artifact_path=os.path.join(context.artifact_path,'models'),
#                   model_file="xgbmodel.pkl",
#                   training_set=train)

with open('svmcmodel.pkl', 'wb') as f:
    dump(svmc, f)
    
# dumps(svmc, open("svmcmodel.pkl", "wb"))
# context.log_model("svmcmodel", 
#                   body=model_bin_svmc,
#                   artifact_path=os.path.join(context.artifact_path,'models'),
#                   model_file="svmcmodel.pkl",
#                   training_set=train)
    